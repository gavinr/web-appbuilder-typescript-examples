define({
  "_themeLabel": "Stendo tema",
  "_layout_default": "Numatytasis maketas",
  "_layout_right": "Dešinys maketas"
});