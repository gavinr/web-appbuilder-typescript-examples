define({
  "_themeLabel": "बिलबोर्ड थीम",
  "_layout_default": "डिफ़ॉल्ट रूपरेखा",
  "_layout_right": "सही रूपरेखा"
});