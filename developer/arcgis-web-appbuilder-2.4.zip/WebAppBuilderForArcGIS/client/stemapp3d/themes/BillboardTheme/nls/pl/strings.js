define({
  "_themeLabel": "Motyw na billboardzie",
  "_layout_default": "Układ domyślny",
  "_layout_right": "Układ prawostronny"
});