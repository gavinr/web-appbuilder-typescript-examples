define({
  "_themeLabel": "Tauluteema",
  "_layout_default": "Oletusasettelu",
  "_layout_right": "Oikea asettelu"
});