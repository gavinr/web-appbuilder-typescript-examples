define({
  "_themeLabel": "Tema Billboard",
  "_layout_default": "Tata Letak Default",
  "_layout_right": "Tata Letak Kanan"
});