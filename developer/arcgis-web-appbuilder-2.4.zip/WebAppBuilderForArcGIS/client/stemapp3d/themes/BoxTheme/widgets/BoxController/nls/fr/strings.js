define({
  "_widgetLabel": "Contrôleur d'encar"
});