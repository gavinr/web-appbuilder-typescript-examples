define({
  "_widgetLabel": "Ruutusäädin"
});