define({
  "_widgetLabel": "상자 컨트롤러"
});