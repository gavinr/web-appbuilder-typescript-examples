define({
  "_widgetLabel": "Controlador da Caixa"
});