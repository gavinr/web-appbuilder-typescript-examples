define({
  "_themeLabel": "Bokstema",
  "_layout_default": "Standard oppsett",
  "_layout_top": "Øverst-oppsett"
});