define({
  "_themeLabel": "Тема \"коробка\"",
  "_layout_default": "Компоновка по умолчанию",
  "_layout_top": "Верх компоновки"
});