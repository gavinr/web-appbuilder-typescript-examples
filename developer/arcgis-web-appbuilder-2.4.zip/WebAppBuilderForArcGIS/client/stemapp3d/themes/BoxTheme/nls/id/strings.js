define({
  "_themeLabel": "Tema Box",
  "_layout_default": "Tata Letak Default",
  "_layout_top": "Tata Letak Atas"
});