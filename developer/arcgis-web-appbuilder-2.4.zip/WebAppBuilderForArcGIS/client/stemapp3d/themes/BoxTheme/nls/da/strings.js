define({
  "_themeLabel": "Bokstema",
  "_layout_default": "Standardlayout",
  "_layout_top": "Toplayout"
});