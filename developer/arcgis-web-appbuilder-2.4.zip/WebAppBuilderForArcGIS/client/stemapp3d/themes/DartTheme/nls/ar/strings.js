define({
  "_themeLabel": "موضوع الانطلاق",
  "_layout_default": "تخطيط افتراضي"
});