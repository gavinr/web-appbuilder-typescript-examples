define({
  "_themeLabel": "Dart-Design",
  "_layout_default": "Standard-Layout"
});