define({
  "default": {
    "name": "Implicit",
    "description": "Implicit"
  }
});