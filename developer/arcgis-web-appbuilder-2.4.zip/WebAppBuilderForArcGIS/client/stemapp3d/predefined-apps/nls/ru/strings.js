define({
  "default": {
    "name": "По умолчанию",
    "description": "По умолчанию"
  }
});