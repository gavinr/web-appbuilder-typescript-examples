define({
  "default": {
    "name": "기본값",
    "description": "기본값"
  }
});