define({
  "default": {
    "name": "الافتراضي",
    "description": "الافتراضي"
  }
});