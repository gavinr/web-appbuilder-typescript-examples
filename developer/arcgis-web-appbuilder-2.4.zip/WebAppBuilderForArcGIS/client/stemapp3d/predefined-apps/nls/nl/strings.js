define({
  "default": {
    "name": "Standaard",
    "description": "Standaard"
  }
});