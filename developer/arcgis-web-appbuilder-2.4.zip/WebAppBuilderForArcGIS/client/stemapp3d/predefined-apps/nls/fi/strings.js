define({
  "default": {
    "name": "Oletus",
    "description": "Oletus"
  }
});