define({
  "default": {
    "name": "Zadano",
    "description": "Zadano"
  }
});