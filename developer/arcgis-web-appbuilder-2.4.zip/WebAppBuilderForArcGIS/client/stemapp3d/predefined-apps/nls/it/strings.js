define({
  "default": {
    "name": "Predefinito",
    "description": "Predefinito"
  }
});