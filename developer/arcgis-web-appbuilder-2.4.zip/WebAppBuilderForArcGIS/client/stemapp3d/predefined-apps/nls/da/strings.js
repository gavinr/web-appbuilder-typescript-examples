define({
  "default": {
    "name": "Standard",
    "description": "Standard"
  }
});