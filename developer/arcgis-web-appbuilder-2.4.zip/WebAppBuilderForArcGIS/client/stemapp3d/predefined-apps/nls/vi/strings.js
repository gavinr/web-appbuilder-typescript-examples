define({
  "default": {
    "name": "Mặc định",
    "description": "Mặc định"
  }
});