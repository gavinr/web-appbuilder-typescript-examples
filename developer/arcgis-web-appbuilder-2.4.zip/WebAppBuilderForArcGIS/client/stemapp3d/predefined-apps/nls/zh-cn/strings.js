define({
  "default": {
    "name": "默认",
    "description": "默认"
  }
});