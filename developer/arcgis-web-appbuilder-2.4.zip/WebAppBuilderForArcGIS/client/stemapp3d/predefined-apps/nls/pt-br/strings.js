define({
  "default": {
    "name": "Padrão",
    "description": "Padrão"
  }
});