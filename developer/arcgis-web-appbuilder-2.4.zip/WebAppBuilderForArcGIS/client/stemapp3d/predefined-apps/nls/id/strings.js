define({
  "default": {
    "name": "Default",
    "description": "Default"
  }
});